package sample;

import casmi.Applet;
import casmi.AppletRunner;
import casmi.graphics.Graphics;

/**
 * Sample Quick Start Project
 *
 */
public class App extends Applet 
{
    public static void main( String[] args )
    {
    	AppletRunner.run("sample.App", "This is a sample quick start project");
    }

	@Override
	public void draw(Graphics g) {
		// TODO implement here
	}

	@Override
	public void setup() {
		setSize(1024, 768);
		// TODO implement here
	}
}
