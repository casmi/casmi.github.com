package sample;

import casmi.Applet;
import casmi.AppletRunner;
import casmi.KeyEvent;
import casmi.MouseButton;
import casmi.MouseEvent;

/**
 * Sample Quick Start Project
 *
 */
public class App extends Applet {

    @Override
    public void setup() {
        // Implement here.
    }

    @Override
    public void update() {
        // Implement here.
    }

    @Override
    public void mouseEvent(MouseEvent e, MouseButton b) {
        // Implement here.
    }

    @Override
    public void keyEvent(KeyEvent e) {
        // Implement here.
    }

    public static void main(String[] args) {
        AppletRunner.run("sample.App", "sample");
    }
}